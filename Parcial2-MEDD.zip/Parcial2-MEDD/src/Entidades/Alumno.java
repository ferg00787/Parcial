
package Entidades;

/**
 *
 * @author apple
 */
public class Alumno {
    public String carnet;
    public String nombre;
    public double nota;
    public String carrera;
    
     public Alumno(String pCarnet, String pNombre, double pNota, String pCarrera)
    {
        this.carnet = pCarnet;
        this.nombre = pNombre;
        this.nota = pNota;
        this.carrera = pCarrera;
    }
}
