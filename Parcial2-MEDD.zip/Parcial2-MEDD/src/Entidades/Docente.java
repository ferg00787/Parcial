
package Entidades;

import java.util.ArrayList;
/**
 *
 * @author apple
 */
public class Docente {
    
    public String nombre;
    public String facultad;
    public String materia;
    public ArrayList<Alumno> lAlumno;

    
}
