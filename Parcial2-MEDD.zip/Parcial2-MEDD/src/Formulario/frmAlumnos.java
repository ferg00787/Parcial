
package Formulario;

import Entidades.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

import java.io.PrintWriter;
import javax.swing.JFileChooser;
import java.io.File;  
import java.util.Scanner;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

import org.apache.pdfbox.pdmodel.font.PDType1Font;



/**
 *
 * @author apple
 */
public class frmAlumnos extends javax.swing.JFrame {

    /**
     * Creates new form frmAlumnos
     */
    ArrayList<Docente> lDocente;
    DefaultTableModel modeloDocen;
    DefaultTableModel modeloAlum;
    
    
    public frmAlumnos() {
        initComponents();
        lDocente= new ArrayList<>();
        modeloDocen= (DefaultTableModel) this.jtDocentes.getModel();
        modeloAlum= (DefaultTableModel) this.jtAlumno.getModel();
        
        Docente docen1= new Docente();
        Docente docen2= new Docente();
        Docente docen3= new Docente();
        Docente docen4= new Docente();
        Docente docen5= new Docente();
        Docente docen6= new Docente();
        Docente docen7= new Docente();
        Docente docen8= new Docente();
        Docente docen9= new Docente();
        Docente docen10= new Docente();
        
        
        docen1.nombre= "Alfredo Baños";
        docen1.facultad = "Ingenieria y Arquitectura";
        docen1.materia = "Dibujo Tecnico";
        docen1.lAlumno =  new ArrayList<>();
        docen1.lAlumno.add(new Alumno("2019GV601","Camila García",9.0,"Arquitectura"));
        docen1.lAlumno.add(new Alumno("2019MM603","Jose Morales",8.5,"Arquitectura"));
        docen1.lAlumno.add(new Alumno("2019ZL608","Nicolle Linares",8.0,"Arquitectura"));
        docen1.lAlumno.add(new Alumno("2019HV614","Pedro Hernandez ",7.0,"Arquitectura"));
        
        
        docen2.nombre= "Natali Ruiz";
        docen2.facultad = "Ciencias de la Salud";
        docen2.materia = "Patología";
        docen2.lAlumno =  new ArrayList<>();
        docen2.lAlumno.add(new Alumno("2015RL504","Daniela Rojas",8.0,"Medicina"));
        docen2.lAlumno.add(new Alumno("2015HR501","Roberto Rodriguez",7.5,"Medicina"));
        docen2.lAlumno.add(new Alumno("2015ZL503","Sofia Zetino",7.3,"Medicina"));
        docen2.lAlumno.add(new Alumno("2015MA512","Juan Martinez ",9.4,"Medicina"));
        
        docen3.nombre= "Juan Magaña";
        docen3.facultad = "Ciencias Empresariales";
        docen3.materia = "Estadística I";
        docen3.lAlumno =  new ArrayList<>();
        docen3.lAlumno.add(new Alumno("2019GP609","Yansi Galdamez",9.6,"Mercadeo"));
        docen3.lAlumno.add(new Alumno("2019RT611","Valeria Rios",8.8,"Mercadeo"));
        docen3.lAlumno.add(new Alumno("2019BP615","Sebastian Beltran",8.6,"Mercadeo"));
        docen3.lAlumno.add(new Alumno("2019MJ621","Marielos Menjivar ",7.2,"Mercadeo"));
        
        
        docen4.nombre= "Claudia Chavez";
        docen4.facultad = "Ciencias y Humanidades";
        docen4.materia = "Desarrollo Profesional";
        docen4.lAlumno =  new ArrayList<>();
        docen4.lAlumno.add(new Alumno("2017AR403","Jose Alvarez",6.6,"Lic.en Educación"));
        docen4.lAlumno.add(new Alumno("2017MZ405","Paola Morales",9.8,"Lic.en Educación"));
        docen4.lAlumno.add(new Alumno("2017RE412","Mauricio Rodriguez",7.6,"Lic.en Educación"));
        docen4.lAlumno.add(new Alumno("2017ZA428","Paola Zepeda ",8.2,"Lic.en Educación"));
        
        docen5.nombre= "Alberto Ramirez";
        docen5.facultad = "Ciencias de la Salud";
        docen5.materia = "Bioquimica";
        docen5.lAlumno =  new ArrayList<>();
        docen5.lAlumno.add(new Alumno("2018GL303","Antonio Gomez",6.0,"Enfermeria"));
        docen5.lAlumno.add(new Alumno("2018MK305","Monica Molina",7.0,"Enfermeria"));
        docen5.lAlumno.add(new Alumno("2018RH312","Mauricio Rodriguez",7.1,"Enfermeria"));
        docen5.lAlumno.add(new Alumno("2018SL320","Nicolle Soto",8.0,"Enfermeria"));
        
        docen6.nombre= "Alejandra Estreda";
        docen6.facultad = "Ingenieria y Arquitectura";
        docen6.materia = "Quimica Técnica";
        docen6.lAlumno =  new ArrayList<>();
        docen6.lAlumno.add(new Alumno("2019RL518","Luisa Ramos",9.0,"Ingenieria Industrial"));
        docen6.lAlumno.add(new Alumno("2019HC520","Andrea Herrera",8.3,"Ingenieria Industrial"));
        docen6.lAlumno.add(new Alumno("2019PO525","Claudia Pacheco",7.8,"Ingenieria Industrial"));
        docen6.lAlumno.add(new Alumno("2019MS534","Rodrigo Monroy",8.9,"Ingenieria Industrial"));
        
        
        docen7.nombre= "Humberto Alvarez";
        docen7.facultad = "Ciencias Empresariales";
        docen7.materia = "Matematica II";
        docen7.lAlumno =  new ArrayList<>();
        docen7.lAlumno.add(new Alumno("2019RF622","Alessandra Ramirez",8.1,"Negocios Internacionales"));
        docen7.lAlumno.add(new Alumno("2019FH635","Rafael Francia",6.3,"Negocios Internacionales"));
        docen7.lAlumno.add(new Alumno("2019HE633","Alfredo Esquivel",6.1,"Negocios Internacionales"));
        docen7.lAlumno.add(new Alumno("2019MP657","Monica Montes",7.0,"Negocios Internacionales"));
        
        docen8.nombre= "Ruth Gomez";
        docen8.facultad = "Ciencias y Humanidades";
        docen8.materia = "Basic English";
        docen8.lAlumno =  new ArrayList<>();
        docen8.lAlumno.add(new Alumno("2018CK330","Rodrigo Castillo",9.1,"Lic. Idioma Ingles"));
        docen8.lAlumno.add(new Alumno("2018HS335","Fatima Herrera",8.5,"Lic. Idioma Ingles"));
        docen8.lAlumno.add(new Alumno("2018TC333","Josselyn Torres",8.8,"Lic. Idioma Ingles"));
        docen8.lAlumno.add(new Alumno("2018VH357","Pablo Valle",9.7,"Lic. Idioma Ingles"));
        
        docen9.nombre= "Jose Mendoza";
        docen9.facultad = "Ciencias de la Salud";
        docen9.materia = "Medicina Interna";
        docen9.lAlumno =  new ArrayList<>();
        docen9.lAlumno.add(new Alumno("2015MR430","Kevin Munguía",7.1,"Medicina"));
        docen9.lAlumno.add(new Alumno("2015PC435","Andrea Posada",7.6,"Medicina"));
        docen9.lAlumno.add(new Alumno("2015GL433","Ana Granados",8.1,"Medicina"));
        docen9.lAlumno.add(new Alumno("2015VG457","Miguel Vega",6.7,"Medicina"));
        
        docen10.nombre= "Rosio Linares";
        docen10.facultad = "Ingenieria y Arquitectura";
        docen10.materia = "Progrmación II";
        docen10.lAlumno =  new ArrayList<>();
        docen10.lAlumno.add(new Alumno("2018HU450","Natilia Herrera",8.1,"Ingeniería en Sistemas"));
        docen10.lAlumno.add(new Alumno("2018LP455","Alexander Lemus",9.6,"Ingeniería en Sistemas"));
        docen10.lAlumno.add(new Alumno("2018CG453","Juan José Chavéz",7.3,"Ingeniería en Sistemas"));
        docen10.lAlumno.add(new Alumno("2018SO467","Hugo Sandoval",8.7,"Ingeniería en Sistemas"));
        
        
        
        
        this.lDocente.add(docen1);
        this.lDocente.add(docen2);
        this.lDocente.add(docen3);
        this.lDocente.add(docen4);
        this.lDocente.add(docen5);
        this.lDocente.add(docen6);
        this.lDocente.add(docen7);
        this.lDocente.add(docen8);
        this.lDocente.add(docen9);
        this.lDocente.add(docen10);
            
        

        
    }
    

       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtDocentes = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtAlumno = new javax.swing.JTable();
        btnMostrar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnPDF = new javax.swing.JButton();
        btnCSV = new javax.swing.JButton();
        btnHTML = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(102, 102, 102)));

        jtDocentes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Facultad", "Materia"
            }
        ));
        jtDocentes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtDocentesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtDocentes);

        jtAlumno.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Carnet", "Nombre", "Nota de Materia", "Carrera"
            }
        ));
        jScrollPane2.setViewportView(jtAlumno);

        btnMostrar.setBackground(new java.awt.Color(153, 255, 153));
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Al Nile", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Listado de Alumnos");

        jLabel3.setFont(new java.awt.Font("Al Nile", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 153, 255));
        jLabel3.setText("Listado de Docentes");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 854, Short.MAX_VALUE)
                            .addComponent(jScrollPane1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnMostrar, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(382, 382, 382)
                        .addComponent(jLabel3)))
                .addGap(12, 12, 12))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        jLabel1.setBackground(new java.awt.Color(51, 204, 255));
        jLabel1.setFont(new java.awt.Font("Al Nile", 1, 24)); // NOI18N
        jLabel1.setText("REGISTRO DE ALUMNOS");

        btnPDF.setBackground(new java.awt.Color(255, 153, 51));
        btnPDF.setText("Generar PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });

        btnCSV.setBackground(new java.awt.Color(255, 153, 0));
        btnCSV.setText("Exportar CSV");
        btnCSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCSVActionPerformed(evt);
            }
        });

        btnHTML.setBackground(new java.awt.Color(255, 153, 0));
        btnHTML.setText("Exportar HTML");
        btnHTML.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHTMLActionPerformed(evt);
            }
        });

        btnSalir.setBackground(new java.awt.Color(255, 0, 0));
        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane3.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCSV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnPDF, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                            .addComponent(btnHTML, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(29, 29, 29))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(553, 553, 553))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(37, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnPDF, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76)
                        .addComponent(btnCSV, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78)
                        .addComponent(btnHTML, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(77, 77, 77)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
           for(int i=0; i<this.lDocente.size(); i++)
        {
            String[] registroD = {this.lDocente.get(i).nombre, 
                                  this.lDocente.get(i).facultad,
                                  this.lDocente.get(i).materia};
            modeloDocen.addRow(registroD);
        }
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jtDocentesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtDocentesMouseClicked
        modeloAlum.getDataVector().removeAllElements(); 
        
        int indiceDocente=this.jtDocentes.getSelectedRow();
        int cantAlumnos= this.lDocente.get(indiceDocente).lAlumno.size();
        for(int j=0; j<cantAlumnos; j++)
        {
            String[] registroA = { this.lDocente.get(indiceDocente).lAlumno.get(j).carnet,
                                   this.lDocente.get(indiceDocente).lAlumno.get(j).nombre,
                                   Double.toString(this.lDocente.get(indiceDocente).lAlumno.get(j).nota),
                                    this.lDocente.get(indiceDocente).lAlumno.get(j).carrera
                                    };
            modeloAlum.addRow(registroA);
         }
    }//GEN-LAST:event_jtDocentesMouseClicked

    private void btnCSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCSVActionPerformed
        PrintWriter pw = null;
     
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(this);
        File selectedFile=null;
        if (result == JFileChooser.APPROVE_OPTION) 
        {
            selectedFile = fileChooser.getSelectedFile();
            System.out.println("Archivo seleccionado: " + selectedFile.getAbsolutePath());
        }
        try 
        {
            pw = new PrintWriter(new File(selectedFile.getAbsolutePath()));
        }
        catch (Exception e) 
        {
            this.jTextArea1.setText("Ocurrio un Error: "+e.toString());
        }
        
        StringBuilder strLinea = new StringBuilder();
        String ColumnNamesList = "<Docente1>, Alfredo Baños, Facultad de Ingeniería y Arquitectura, Dibujo Técnico";
       
       
        strLinea.append(ColumnNamesList +"\n");
        strLinea.append("<Alumno1>,2019GV601, Camila García, 9.0, Arquitectura\n");
        strLinea.append("<Alumno2>,2019MM603,Jose Morales,8.5,Arquitectura\n");
        strLinea.append("<Alumno3>,2019ZL608,Nicolle Linares,8.0,Arquitectura\n");
        strLinea.append("<Alumno4>,2019HV614,Pedro Hernandez ,7.0,Arquitectura \n");
        
        String ColumnNamesList2 = "<Docente2>, Natali Ruiz, Facultad de Ciencias de la Salud, Patología";
       
       
        strLinea.append(ColumnNamesList2 +"\n");
        strLinea.append("<Alumno1>,2015RL504,Daniela Rojas,8.0,Medicina\n");
        strLinea.append("<Alumno2>,2015HR501,Roberto Rodriguez,7.5,Medicina\n");
        strLinea.append("<Alumno3>,2015ZL503,Sofia Zetino,7.3,Medicina\n");
        strLinea.append("<Alumno4>,2015MA512,Juan Martinez ,9.4,Medicina\n");
        
        
        String ColumnNamesList3 = "<Docente3>, Juanjo Magaña, Facultad de Ciencias Empreariales, Estadistíca I";
       
       
        strLinea.append(ColumnNamesList3 +"\n");
        strLinea.append("<Alumno1>,2019GP609,Yansi Galdamez,9.6,Mercadeo\n");
        strLinea.append("<Alumno2>,2019RT611,Valeria Rios,8.8,Mercadeo\n");
        strLinea.append("<Alumno3>,2019BP615,Sebastian Beltran,8.6,Mercadeo\n");
        strLinea.append("<Alumno4>,2019MJ621,Marielos Menjivar,7.2,Mercadeo\n");
        
        String ColumnNamesList4 = "<Docente4>, Claudia Chavez, Facultad de Ciencias y Humanidades, Desarrollo Profesional";
       
       
        strLinea.append(ColumnNamesList4 +"\n");
        strLinea.append("<Alumno1>,2017AR403,Jose Alvarez,6.6,Lic.en Educación\n");
        strLinea.append("<Alumno2>,2017MZ40,Paola Morales,9.8,Lic.en Educación\n");
        strLinea.append("<Alumno3>,2017RE412,Mauricio Rodrigue,7.6,Lic.en Educación\n");
        strLinea.append("<Alumno4>,2017ZA428,Paola Zepeda,8.2,Lic.en Educación\n");
        
        String ColumnNamesList5 = "<Docente5>, Alberto Ramirez, Facultad de Ciencias de la Salud, Bioquimica";
       
       
        strLinea.append(ColumnNamesList5 +"\n");
        strLinea.append("<Alumno1>,2018GL303,Antonio Gomez,6.0,Enfermeria\n");
        strLinea.append("<Alumno2>,2018MK305,Monica Molina,7.0,Enfermeria\n");
        strLinea.append("<Alumno3>,2018RH312,Mauricio Rodriguez,7.1,Enfermeria\n");
        strLinea.append("<Alumno4>,2018SL320,Nicolle Soto,8.0,Enfermeria\n");
        
         
        String ColumnNamesList6 = "<Docente6>, Alejandra Estrada, Facultad de Ingeniería y Arquitectura, Quimica Técnica";
       
       
        strLinea.append(ColumnNamesList6 +"\n");
        strLinea.append("<Alumno1>,2019RL518 ,Luisa Ramos,9.0,Ingenieria Industrial\n");
        strLinea.append("<Alumno2>,2019HC520,Andrea Herrera,8.3,Ingenieria Industrial\n");
        strLinea.append("<Alumno3>,2019PO525,Claudia Pacheco,7.8,Ingenieria Industrial\n");
        strLinea.append("<Alumno4>,2019MS534,Rodrigo Monroy,8.9,Ingenieria Industrial\n");
        
        String ColumnNamesList7 = "<Docente7>,Humberto Alvarez, Facultad de Ciencias Empresariales, Matematica II";
       
       
        strLinea.append(ColumnNamesList7 +"\n");
        strLinea.append("<Alumno1>,2019RF622,Alessandra Ramirez,8.1,Negocios Internacionalesl\n");
        strLinea.append("<Alumno2>,2019FH635,Rafael Francia,6.3,Negocios Internacionales\n");
        strLinea.append("<Alumno3>,2019HE633,Alfredo Esquivel,6.1,Negocios Internacionales\n");
        strLinea.append("<Alumno4>,2019MP657,Monica Montes,7.0,Negocios Internacionales\n");
        
        String ColumnNamesList8 = "<Docente8>,Ruth Gomez, Facultad de Ciencias y Humanidades, Basic English";
       
       
        strLinea.append(ColumnNamesList8 +"\n");
        strLinea.append("<Alumno1>,2018CK330,Rodrigo Castillo,9.1,Lic. Idioma Ingles\n");
        strLinea.append("<Alumno2>,2018HS335,Fatima Herrera,8.5,Lic. Idioma Ingles\n");
        strLinea.append("<Alumno3>,2018TC333,Josselyn Torres,8.8,Lic. Idioma Ingles\n");
        strLinea.append("<Alumno4>,2018VH357,Pablo Valle,9.7,Lic. Idioma Ingles\n");
        
        String ColumnNamesList9 = "<Docente9>,José Mendoza, Facultad de Ciencias de la Salud, Medicina Interna";
       
       
        strLinea.append(ColumnNamesList9 +"\n");
        strLinea.append("<Alumno1>,2015MR430,Kevin Munguía,7.1,Medicina\n");
        strLinea.append("<Alumno2>,2015PC435,Andrea Posada,7.6,Medicina\n");
        strLinea.append("<Alumno3>,2015GL433,Ana Granados,8.1,Medicina\n");
        strLinea.append("<Alumno4>,2015VG457,Miguel Vega,6.7,Medicina\n");
        
        String ColumnNamesList10 = "<Docente10>,Rosio Linares, Facultad de Ingenieria y Arquitectura, Programción II";
       
       
        strLinea.append(ColumnNamesList10 +"\n");
        strLinea.append("<Alumno1>,2018HU450,Natilia Herrera,8.1,Ingeniería en Sistemas\n");
        strLinea.append("<Alumno2>,2018LP455,Alexander Lemus,9.6,Ingeniería en Sistemas\n");
        strLinea.append("<Alumno3>,2018CG453,Juan José Chavéz,7.3,Ingeniería en Sistemas\n");
        strLinea.append("<Alumno4>,22018SO467,Hugo Sandoval,8.7,Ingeniería en Sistemas\n");
        
        pw.write(strLinea.toString());
        pw.close();
        System.out.println("Hecho!");
        
    }//GEN-LAST:event_btnCSVActionPerformed

    private void btnHTMLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHTMLActionPerformed
        PrintWriter pw = null;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(this);
        File selectedFile=null;
        if (result == JFileChooser.APPROVE_OPTION) 
        {
            selectedFile = fileChooser.getSelectedFile();
            System.out.println("Archivo seleccionado: " + selectedFile.getAbsolutePath());
        }
        try 
        {
            pw = new PrintWriter(new File(selectedFile.getAbsolutePath()));
        }
        catch (Exception e) 
        {
            this.jTextArea1.setText("ERROR: "+e.toString());
        }
        
        StringBuilder strLinea = new StringBuilder();
        
        
        ArrayList<Alumno> aIns= new ArrayList<>();
        //#1
        aIns.add(new Alumno("2019GV601","Camila García",9.0,"Arquitectura"));
        aIns.add(new Alumno("2019MM603","Jose Morales",8.5,"Arquitectura"));
        aIns.add(new Alumno("2019ZL608","Nicolle Linares",8.0,"Arquitectura"));
        aIns.add(new Alumno("2019HV614","Pedro Hernandez ",7.0,"Arquitectura"));
        //#2
        aIns.add(new Alumno("2015RL504","Daniela Rojas",8.0,"Medicina"));
        aIns.add(new Alumno("2015HR501","Roberto Rodriguez",7.5,"Medicina"));
        aIns.add(new Alumno("2015ZL503","Sofia Zetino",7.3,"Medicina"));
        aIns.add(new Alumno("2015MA512","Juan Martinez" ,9.4,"Medicina"));
        //#3
        aIns.add(new Alumno("2019GP609","Yansi Galdamez",9.6,"Mercadeo"));
        aIns.add(new Alumno("2019RT611","Valeria Rios",8.8,"Mercadeo"));
        aIns.add(new Alumno("2019BP615","Sebastian Beltran",8.6,"Mercadeo"));
        aIns.add(new Alumno("2019MJ621","Marielos Menjivar ",7.2,"Mercadeo"));
        //#4
        aIns.add(new Alumno("2017AR403","Jose Alvarez",6.6,"Lic.en Educación"));
        aIns.add(new Alumno("2017MZ405","Paola Morales",9.8,"Lic.en Educación"));
        aIns.add(new Alumno("2017RE412","Mauricio Rodriguez",7.6,"Lic.en Educación"));
        aIns.add(new Alumno("2017ZA428","Paola Zepeda ",8.2,"Lic.en Educación"));
        //#5
        aIns.add(new Alumno("2018GL303","Antonio Gomez",6.0,"Enfermeria"));
        aIns.add(new Alumno("2018MK305","Monica Molina",7.0,"Enfermeria"));
        aIns.add(new Alumno("2018RH312","Mauricio Rodriguez",7.1,"Enfermeria"));
        aIns.add(new Alumno("2018SL320","Nicolle Soto",8.0,"Enfermeria"));
        //#6
        aIns.add(new Alumno("2019RL518","Luisa Ramos",9.0,"Ingenieria Industrial"));
        aIns.add(new Alumno("2019HC520","Andrea Herrera",8.3,"Ingenieria Industrial"));
        aIns.add(new Alumno("2019PO525","Claudia Pacheco",7.8,"Ingenieria Industrial"));
        aIns.add(new Alumno("2019MS534","Rodrigo Monroy",8.9,"Ingenieria Industrial"));
        //#7
        aIns.add(new Alumno("2019RF622","Alessandra Ramirez",8.1,"Negocios Internacionales"));
        aIns.add(new Alumno("2019FH635","Rafael Francia",6.3,"Negocios Internacionales"));
        aIns.add(new Alumno("2019HE633","Alfredo Esquivel",6.1,"Negocios Internacionales"));
        aIns.add(new Alumno("2019MP657","Monica Montes",7.0,"Negocios Internacionales"));
        //#8
        aIns.add(new Alumno("2018CK330","Rodrigo Castillo",9.1,"Lic. Idioma Ingles"));
        aIns.add(new Alumno("2018HS335","Fatima Herrera",8.5,"Lic. Idioma Ingles"));
        aIns.add(new Alumno("2018TC333","Josselyn Torres",8.8,"Lic. Idioma Ingles"));
        aIns.add(new Alumno("2018VH357","Pablo Valle",9.7,"Lic. Idioma Ingles"));
        //#9
        aIns.add(new Alumno("2015MR430","Kevin Munguía",7.1,"Medicina"));
        aIns.add(new Alumno("2015PC435","Andrea Posada",7.6,"Medicina"));
        aIns.add(new Alumno("2015GL433","Ana Granados",8.1,"Medicina"));
        aIns.add(new Alumno("2015VG457","Miguel Vega",6.7,"Medicina"));
        //#10
        aIns.add(new Alumno("2018HU450","Natilia Herrera",8.1,"Ingeniería en Sistemas"));
        aIns.add(new Alumno("2018LP455","Alexander Lemus",9.6,"Ingeniería en Sistemas"));
        aIns.add(new Alumno("2018CG453","Juan José Chavéz",7.3,"Ingeniería en Sistemas"));
        aIns.add(new Alumno("2018SO467","Hugo Sandoval",8.7,"Ingeniería en Sistemas"));
       
        
        // ARMAR EL ARCHIVO XML....
        strLinea.append("<html><body><table border='2'>" +"\n");
        strLinea.append("<tr><td><b>Carnet.</td><td><b>Nomb.</td><td><b>Nota.</td><td><b>Carrera.</td></tr>" +"\n");
        for(int i=0; i<aIns.size(); i++)
        {
            strLinea.append("<tr>" +"\n");
            // 1 PROP
            strLinea.append("<td>");
            strLinea.append(aIns.get(i).carnet);
            strLinea.append("</td>" +"\n");
            // 2 PROP
            strLinea.append("<td>");
            strLinea.append(aIns.get(i).nombre);
            strLinea.append("</td>" +"\n");
            // 3 PROP
            strLinea.append("<td>");
            strLinea.append(Double.toString(aIns.get(i).nota));
            strLinea.append("</td>" +"\n");
             // 4 PROP
            strLinea.append("<td>");
            strLinea.append(aIns.get(i).carrera);
            strLinea.append("</td>" +"\n");
            
            strLinea.append("</tr>" +"\n");
        }
        strLinea.append("</table></body></html>" +"\n");
        
        
         
        
        pw.write(strLinea.toString());
        pw.close();

        
        
        
    }//GEN-LAST:event_btnHTMLActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
         String filename = "registro_dealumnos.pdf";
         
         try 
	 {
            PDDocument doc= new PDDocument();
            PDPage page = new PDPage();
            doc.addPage(page);
          

            PDPageContentStream contents = new PDPageContentStream(doc, page);
            
            //titulo
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 24);
            contents.newLineAtOffset(160,710);
            contents.showText("Registro de Alumnos");
            contents.endText();
            //subtitulo-docente 1
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 16);
            contents.newLineAtOffset(60,675);
            contents.showText("Docente#1:");
            contents.endText();
            //parrafo 1
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents.newLineAtOffset(60, 655);
            contents.showText( "Nombre: Alfredo Baños- Facultad: Ingenieria y Arquitectura- Materia: Dibujo Tecnico");
            contents.endText();
            //subtitulo
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 16);
            contents.newLineAtOffset(60,610);
            contents.showText("Alumnos:");
            contents.endText();
            // parrafo 2
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 590);
            contents.showText("1. Carnet: 2019GV601- Nombre: Camila García- Nota: 9.0- Carrera: Arquitectura");
            contents.endText();
            //parrafo 3
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 570);
            contents.showText("2. Carnet: 2019MM603- Nombre: Jose Morales- Nota: 8.5- Carrera: Arquitectura");
            contents.endText();
            //parrafo 4
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 550);
            contents.showText("3. Carnet: 2019ZL608- Nombre: Nicolle Linares- Nota: 8.0- Carrera: Arquitectura");
            contents.endText();
            //parrafo 5
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 530);
            contents.showText("4. Carnet: 2019HV614- Nombre: Pedro Hernandez- Nota: 7.0- Carrera: Arquitectura");
            contents.endText();
            
            
            //subtitulo-docente 2
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 16);
            contents.newLineAtOffset(60,490);
            contents.showText("Docente#2: ");
            contents.endText();
            //parrafo 6
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents.newLineAtOffset(60,470);
            contents.showText("Nombre: Natali Ruiz- Facultad: Ciencias de la Salud- Materia: Patología");
            contents.endText();
            //subtitulo
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 16);
            contents.newLineAtOffset(60,430);
            contents.showText("Alumnos: ");
            contents.endText();
            //parrafo 7
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 410);
            contents.showText("1. Carnet: 2015RL504- Nombre: Daniela Rojas- Nota: 8.0- Carrera: Medicina");
            contents.endText();
            //parrafo 8
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 390);
            contents.showText("2. Carnet: 2015HR501- Nombre: Roberto Rodriguez- Nota: 7.5- Carrera: Medicina");
            contents.endText();
            //parrafo 9
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 370);
            contents.showText("3. Carnet: 2015ZL503- Nombre: Sofia Zetino- Nota: 7.3- Carrera: Medicina");
            contents.endText();
            //parrafo 10
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 350);
            contents.showText("4: Carnet: 2015MA512- Nombre: Juan Martinez- Nota: 9.4- Carrera: Medicina");
            contents.endText();
            
            
            //subtitulo- docente 3
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 16);
            contents.newLineAtOffset(60, 300);
            contents.showText("Docente#3:");
            contents.endText();
            //parrafo 11
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents.newLineAtOffset(60, 280);
            contents.showText("Nombre: Juanjo Magaña- Facultad: Ciencias Empreariales- Materia: Estadistíca I");
            contents.endText();
            //subtitulo
            contents.beginText();
            contents.setFont(PDType1Font.COURIER_BOLD, 16);
            contents.newLineAtOffset(60, 240);
            contents.showText("Alumnos: ");
            contents.endText();
            //parrafo 12
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 220);
            contents.showText("1. Carnet: 2019GP609- Nombre: Yansi Galdamez- Nota: 9.6- Carrera: Mercadeo");
            contents.endText();
            //parrafo 13
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 200);
            contents.showText("2. Carnet: 2019RT611- Nombre: Valeria Rios- Nota: 8.8- Carrera: Mercadeo");
            contents.endText();
            //parrafo 14
             contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 180);
            contents.showText("3. Carnet: 2019BP615. Nombre: Sebastian Beltran- Nota: 8.6- Carrera: Mercadeo");
            contents.endText();
            //parrafo 15
            contents.beginText();
            contents.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents.newLineAtOffset(60, 160);
            contents.showText("4. Carnet: 2019MJ621- Nombre: Marielos Menjivar- Nota: 7.2- Carrera: Mercadeo");
            contents.endText();
            contents.close();
            
            
            //PAGINA 2
            PDPage page2 = new PDPage();
            doc.addPage(page2);
            PDPageContentStream contents2 = new PDPageContentStream(doc, page2);
            
            //subtitulo-docente 4
            contents2.beginText();
            contents2.setFont(PDType1Font.COURIER_BOLD, 16);
            contents2.newLineAtOffset(60,675);
            contents2.showText("Docente#4:");
            contents2.endText();
            //parrafo 16
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents2.newLineAtOffset(60, 655);
            contents2.showText("Nombre: Claudia Chavez- Facultad: Ciencias y Humanidades- Materia: Desarrollo Profesional");
            contents2.endText();
            //subtitulo
            contents2.beginText();
            contents2.setFont(PDType1Font.COURIER_BOLD, 16);
            contents2.newLineAtOffset(60,610);
            contents2.showText("Alumnos:");
            contents2.endText();
            //parrafo 17
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 590);
            contents2.showText("1. Carnet: 2017AR403- Nombre: Jose Alvarez- Nota: 6.6- Carrera: Lic.en Educación");
            contents2.endText();
            //parrafo 18
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 570);
            contents2.showText("2. Carnet: 2017MZ40- Nombre: Paola Morales- Nota: 9.8- Carrera: Lic.en Educación");
            contents2.endText();
            //parrafo 19
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 550);
            contents2.showText("3. Carnet: 2017RE412- Nombre: Mauricio Rodrigue- Nota: 7.6- Carrera: Lic.en Educación");
            contents2.endText();
            //parrafo 20
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 530);
            contents2.showText("4. Carnet: 2017ZA428- Nombre: Paola Zepeda- Nota: 8.2- Carrera: Lic.en Educación");
            contents2.endText();
            
            
            //subtitulo-docente 5
            contents2.beginText();
            contents2.setFont(PDType1Font.COURIER_BOLD, 16);
            contents2.newLineAtOffset(60,490);
            contents2.showText("Docente#5: ");
            contents2.endText();
            //parrafo 21
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents2.newLineAtOffset(60,470);
            contents2.showText("Nombre: Alberto Ramirez- Facultad: Ciencias de la Salud- Materia: Bioquimica");
            contents2.endText();
            //subtitulo
            contents2.beginText();
            contents2.setFont(PDType1Font.COURIER_BOLD, 16);
            contents2.newLineAtOffset(60,430);
            contents2.showText("Alumnos: ");
            contents2.endText();
            //parrafo 22
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 410);
            contents2.showText("1. Carnet: 2018GL303- Nombre: Antonio Gomez- Nota: 6.0- Carrera: Enfermeria");
            contents2.endText();
            //parrafo 23
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 390);
            contents2.showText("2. Carnet: 2018MK305- Nombre: Monica Molina- Nota: 7.0- Carrera: Enfermeria");
            contents2.endText();
            //parrafo 24
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 370);
            contents2.showText("3. Carnet: 2018RH312- Nombre: Mauricio Rodriguez- Nota: 7.1- Carrera: Enfermeria");
            contents2.endText();
            //parrafo 25
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 350);
            contents2.showText("4. Carnet: 2018SL320- Nombre: Nicolle Soto- Nota: 8.0- Carrera: Enfermeria");
            contents2.endText();
            
            
            //subtitulo- docente 6
            contents2.beginText();
            contents2.setFont(PDType1Font.COURIER_BOLD, 16);
            contents2.newLineAtOffset(60, 300);
            contents2.showText("Docente#6:");
            contents2.endText();
            //parrafo 26
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents2.newLineAtOffset(60, 280);
            contents2.showText("Nombre: Alejandra Estrada- Facultad: Ingeniería y Arquitectura- Materia: Quimica Técnica");
            contents2.endText();
            //subtitulo
            contents2.beginText();
            contents2.setFont(PDType1Font.COURIER_BOLD, 16);
            contents2.newLineAtOffset(60, 240);
            contents2.showText("Alumnos: ");
            contents2.endText();
            //parrafo 27
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 220);
            contents2.showText("1. Carnet: 2019RL518- Nombre: Luisa Ramos- Nota: 9.0- Carrera: Ingenieria Industrial");
            contents2.endText();
            //parrafo 28
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 200);
            contents2.showText("2. Carnet: 2019HC520- Nombre: Andrea Herrera- Nota: 8.3- Carrera: Ingenieria Industrial");
            contents2.endText();
            //parrafo 29
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 180);
            contents2.showText("3. Carnet: 2019MS534- Nombre: Rodrigo Monroy- Nota: 8.9- Carrera: Ingenieria Industrial");
            contents2.endText();
            //parrafo 30
            contents2.beginText();
            contents2.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents2.newLineAtOffset(60, 160);
            contents2.showText("4. Carnet: 2019MS534- Nombre: Rodrigo Monroy- Nota: 8.9- Carrera: Ingenieria Industrial");
            contents2.endText();
            contents2.close();
          
            
            
            //PAGINA 3
            PDPage page3 = new PDPage();
            doc.addPage(page3);
            PDPageContentStream contents3 = new PDPageContentStream(doc, page3);
            
            //subtitulo-docente 7
            contents3.beginText();
            contents3.setFont(PDType1Font.COURIER_BOLD, 16);
            contents3.newLineAtOffset(60,675);
            contents3.showText("Docente#7:");
            contents3.endText();
            //parrafo 31
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents3.newLineAtOffset(60, 655);
            contents3.showText("Nombre: Humberto Alvarez- Facultad: Ciencias Empresariales- Materia: Matematica II");
            contents3.endText();
            //subtitulo
            contents3.beginText();
            contents3.setFont(PDType1Font.COURIER_BOLD, 16);
            contents3.newLineAtOffset(60,610);
            contents3.showText("Alumnos:");
            contents3.endText();
            //parrafo 32
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 590);
            contents3.showText("1. Carnet: 2019RF622- Nombre: Alessandra Ramirez- Nota: 8.1- Carrera: Negocios Internacionalesl");
            contents3.endText();
            //parrafo 33
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 570);
            contents3.showText("2. Carnet: 2019FH635- Nombre: Rafael Francia- Nota: 6.3- Carrera: Negocios Internacionales");
            contents3.endText();
            //parrafo 34
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 550);
            contents3.showText("3. Carnet: 2019HE633- Nombre: Alfredo Esquivel- Nota: 6.1- Carrera: Negocios Internacionales");
            contents3.endText();
            //parrafo 35
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 530);
            contents3.showText("4. Carnet: 2019MP657- Nombre: Monica Montes- Nota: 7.0- Carrera: Negocios Internacionales");
            contents3.endText();
            
            //subtitulo-docente 8
            contents3.beginText();
            contents3.setFont(PDType1Font.COURIER_BOLD, 16);
            contents3.newLineAtOffset(60,490);
            contents3.showText("Docente#8: ");
            contents3.endText();
            //parrafo 36
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents3.newLineAtOffset(60,470);
            contents3.showText("Nombre: Ruth Gomez- Facultad: Ciencias y Humanidades- Materia: Basic English");
            contents3.endText();
            //subtitulo
            contents3.beginText();
            contents3.setFont(PDType1Font.COURIER_BOLD, 16);
            contents3.newLineAtOffset(60,430);
            contents3.showText("Alumnos: ");
            contents3.endText();
            //parrafo 37
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 410);
            contents3.showText("1. Carnet: 2018CK330- Nombre: Rodrigo Castillo- Nota: 9.1- Carrera: Lic. Idioma Ingles");
            contents3.endText();
            //parrafo 38
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 390);
            contents3.showText("2. Carnet: 2018HS335- Nombre: Fatima Herrera- Nota: 8.5- Carrera: Lic. Idioma Ingles");
            contents3.endText();
            //parrafo 39
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 370);
            contents3.showText("3. Carnet: 2018TC333- Nombre: Josselyn Torres- Nota: 8.8- Carrera: Lic. Idioma Ingles");
            contents3.endText();
            //parrafo 40
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 350);
            contents3.showText("4. Carnet: 2018VH357- Nombre: Pablo Valle- Nota: 9.7- Carrera: Lic. Idioma Ingles");
            contents3.endText();
            
            
            //subtitulo- docente 9
            contents3.beginText();
            contents3.setFont(PDType1Font.COURIER_BOLD, 16);
            contents3.newLineAtOffset(60, 300);
            contents3.showText("Docente#9:");
            contents3.endText();
            //parrafo 41
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents3.newLineAtOffset(60, 280);
            contents3.showText("Nombre: José Mendoza- Facultad: Ciencias de la Salud- Materia: Medicina Interna");
            contents3.endText();
            //subtitulo
            contents3.beginText();
            contents3.setFont(PDType1Font.COURIER_BOLD, 16);
            contents3.newLineAtOffset(60, 240);
            contents3.showText("Alumnos: ");
            contents3.endText();
            //parrafo 42
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 220);
            contents3.showText("1. Carnet: 2015MR430- Nombre: Kevin Munguía- Nota: 7.1- Carrera: Medicina");
            contents3.endText();
            //parrafo 43
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 200);
            contents3.showText("2. Carnet: 2015PC435- Nombre: Andrea Posada- Nota: 7.6- Carrera: Medicina");
            contents3.endText();
            //parrafo 44
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 180);
            contents3.showText("3. Carnet: 2015GL433- Nombre: Ana Granados- Nota: 8.1- Carrera: Medicina");
            contents3.endText();
            //parrafo 45
            contents3.beginText();
            contents3.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents3.newLineAtOffset(60, 160);
            contents3.showText("4. Carnet: 2015VG457- Nombre: Miguel Vega- Nota: 6.7- Carrera: Medicina");
            contents3.endText();
            contents3.close();
            
            
            //PAGINA 4
            PDPage page4 = new PDPage();
            doc.addPage(page4);
            PDPageContentStream contents4 = new PDPageContentStream(doc, page4);
            
            //subtitulo-docente 10
            contents4.beginText();
            contents4.setFont(PDType1Font.COURIER_BOLD, 16);
            contents4.newLineAtOffset(60,675);
            contents4.showText("Docente#10:");
            contents4.endText();
            //parrafo 46
            contents4.beginText();
            contents4.setFont(PDType1Font.TIMES_ROMAN, 14);
            contents4.newLineAtOffset(60, 655);
            contents4.showText("Nombre: Rosio Linares- Facultad: Ingenieria y Arquitectura- Materia: Programción II");
            contents4.endText();
            //subtitulo
            contents4.beginText();
            contents4.setFont(PDType1Font.COURIER_BOLD, 16);
            contents4.newLineAtOffset(60,610);
            contents4.showText("Alumnos:");
            contents4.endText();
            //parrafo 47
            contents4.beginText();
            contents4.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents4.newLineAtOffset(60, 590);
            contents4.showText("1. Carnet: 2018HU450- Nombre: Natilia Herrera- Nota: 8.1- Carrera: Ingeniería en Sistemas");
            contents4.endText();
            //parrafo 48
            contents4.beginText();
            contents4.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents4.newLineAtOffset(60, 570);
            contents4.showText("2. Carnet: 2018LP455- Nombre: Alexander Lemus- Nota: 9.6- Carrera: Ingeniería en Sistemas");
            contents4.endText();
            //parrafo 49
            contents4.beginText();
            contents4.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents4.newLineAtOffset(60, 550);
            contents4.showText("3. Carnet: 2018CG453- Nombre: Juan José Chavéz- Nota: 7.3- Carrera: Ingeniería en Sistemas");
            contents4.endText();
            //parrafo 50
            contents4.beginText();
            contents4.setFont(PDType1Font.TIMES_ROMAN, 12);
            contents4.newLineAtOffset(60, 530);
            contents4.showText("4. Carnet: 22018SO467- Nombre: Hugo Sandoval- Nota: 8.7- Carrera: Ingeniería en Sistemas");
            contents4 .endText();
            contents4.close();
            
            
            doc.save(filename);
            doc.close();
	 }
         catch(Exception ee) 
         {
             this.jTextArea1.setText(ee.toString());
         }
	 System.out.println("Hecho!");     
	 
    }//GEN-LAST:event_btnPDFActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmAlumnos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCSV;
    private javax.swing.JButton btnHTML;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTable jtAlumno;
    private javax.swing.JTable jtDocentes;
    // End of variables declaration//GEN-END:variables
}
